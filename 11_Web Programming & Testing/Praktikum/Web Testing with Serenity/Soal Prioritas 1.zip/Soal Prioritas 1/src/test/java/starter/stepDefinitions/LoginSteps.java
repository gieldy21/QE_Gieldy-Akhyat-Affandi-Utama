package starter.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;

public class LoginSteps {
    @Steps
    Login login;

    @Steps
    Home home;

    @Given("I am on the login page")
    public void onTheLoginPage(){
        login.openUrl("https://www.saucedemo.com/");
        login.validateOnTheLoginPage();
    }

    @When("I enter valid username")
    public void doEnterValidUsername(){
        login.inputUsername("standard_user");
    }

    @And("I enter valid password")
    public void doEnterValidPassword(){
        login.inputPassword("secret_sauce");
    }

    @And("I click login button")
    public void doClickLoginButton(){
        login.clickButtonLogin();
    }
    @Then("I am on the home page")
    public void onTheHomePage(){
        home.validateOnTheHomePage();
    }

    @When("I enter invalid username")
    public void doEnterInvalidUsername(){
        login.inputUsername("gieldy_akhyat");
    }

    @Then("I see an error notification")
    public void doClickLoginButtonAgain(){
        login.clickButtonLogin();
    }

    @And("I enter invalid password")
    public void doEnterInvalidPassword(){
        login.inputPassword("gieldy");
    }
}
