package starter.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.payment.Payment;

public class PaymentSteps {
    @Steps
    Payment payment;

    @Given("I am on the pulsa page")
    public void onTheHomePageSepulsa(){
        payment.openUrl("https://www.sepulsa.com/transaction/pulsa");
        payment.validateOnThePulsaPageSepulsa();
    }
    @When("I input valid phone number")
    public void doInputValidPhoneNumber(){
        payment.inputNumberPhone("085939647055");
    }
    @And("I choose the product 5000")
    public void doChooseTheProduct5000(){
        payment.chooseTheProduct5000();
    }

    @And("I am on the product 5k XL")
    public void doOnTheProduct5KXL(){
        payment.OnTheProduct5KXL();
    }
    @And("I input email on detail buyer")
    public void doInputEmail(){
        payment.inputEmail("akunsmurfgua@gmail.com");
    }
    @And("I click gopay payment")
    public void doClickGopayPayment(){
        payment.clickGopayPayment();
    }
    @Then("I click pay now")
    public void doClickPayNow(){
        payment.clickPayNow();
    }
    @Then("I click dana payment")
    public void doClickDanaPayment(){ payment.clickDanaPayment();
    }
    @And("I did not fill in email on detail buyer")
    public void notFillEmail(){
        payment.inputEmail("");
    }
    @Then("I see notification error")
    public void doSeeNotificationError(){
        payment.seeNotification();
    }
}
