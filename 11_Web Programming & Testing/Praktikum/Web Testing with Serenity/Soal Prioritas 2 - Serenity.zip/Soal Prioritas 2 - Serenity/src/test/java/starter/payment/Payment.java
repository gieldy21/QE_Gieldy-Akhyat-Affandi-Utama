package starter.payment;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
public class Payment extends PageObject{

    private By titlePulsa(){
        return By.id("phone_number");
    }
    private By inputNumberPhone(){
        return By.id("phone_number");
    }
    private By productsType5k(){
        return By.id("product_type_0");
    }
    private By checkoutDetail(){
        return By.id("checkout_detail");
    }
    private By emailBuyer(){
        return By.id("guest_email");
    }
    private By Gopay(){
        return By.id("checkbox Gopay");
    }
    private By Dana(){
        return By.id("checkbox DANA");
    }
    private By PayNow(){
        return By.id("submit_payment");
    }
    private By Notification(){
        return By.xpath("//p[@style='color: rgb(255, 89, 89);']");
    }
    @Step
    public static OpenUrl url(String targetUrl){
        return new OpenUrl(targetUrl);
    }
    @Step
    public void validateOnThePulsaPageSepulsa(){
        $(titlePulsa()).isDisplayed();
    }
    @Step
    public void inputNumberPhone(String numberphone){
        $(inputNumberPhone()).type(numberphone);
    }
    @Step
    public void chooseTheProduct5000(){
        $(productsType5k()).isClickable();
    }
    @Step
    public void OnTheProduct5KXL(){
        $(checkoutDetail()).isDisplayed();
    }
    @Step
    public void inputEmail(String email){
        $(emailBuyer()).type(email);
    }
    @Step
    public void clickGopayPayment(){
        $(Gopay()).isClickable();
    }
    @Step
    public void clickPayNow(){
        $(PayNow()).isClickable();
    }
    @Step
    public void clickDanaPayment(){
        $(Dana()).isClickable();
    }
    @Step
    public void seeNotification(){
        $(Notification()).isDisplayed();
    }
}
