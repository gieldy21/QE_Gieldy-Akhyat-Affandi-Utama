package starter.login;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class Home extends PageObject {
    private By productsType(){
        return By.id("product_type_0");
    }

    @Step
    public void validateOnTheHomePage(){
        $(productsType()).isDisplayed();
    }
}
