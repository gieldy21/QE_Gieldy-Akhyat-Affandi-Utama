package starter.produk;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
public class Pulsa extends PageObject{
    private By clickNumberPhone(){
        return By.id("phone_number");
    }
    @Step
    public void validateOnThePulsaPage(){
        $(clickNumberPhone()).isDisplayed();
    }

}