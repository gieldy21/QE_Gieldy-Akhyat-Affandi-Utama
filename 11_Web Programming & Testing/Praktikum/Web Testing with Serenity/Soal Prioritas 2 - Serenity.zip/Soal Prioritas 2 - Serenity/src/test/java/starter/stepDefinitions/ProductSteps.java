package starter.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.produk.Product;
import starter.produk.Pulsa;

public class ProductSteps {
    @Steps
    Product product;
    @Steps
    Pulsa pulsa;

    @Given("I am on the home page sepulsa")
    public void onTheHomePageSepulsa(){
        product.openUrl("https://www.sepulsa.com");
        product.validateOnTheHomePageSepulsa();
    }
    @When("I click logo pulsa")
    public void clickLogoPulsa(){
        product.clickLogoPulsa();
    }
    @And("I on the pulsa page")
    public void onThePulsaPage(){
        pulsa.openUrl("https://www.sepulsa.com/transaction/pulsa");
        pulsa.validateOnThePulsaPage();
    }
    @And("I enter the phone number")
    public void doEnterNumberPhone(){
        product.enterNumberPhone("085939647055");
    }
    @Then("I choose the product")
    public void chooseTheProduct(){
        product.chooseTheProduct();
    }
    @And("I enter the invalid phone number")
    public void doEnterinvalidNumberPhone(){
        product.enterNumberPhone("458935896540");
    }
    @Then("I cant see the product")
    public void cantSeeTheProduct(){
        pulsa.validateOnThePulsaPage();
    }
    @Then("I choose the product 2")
    public void chooseTheProduct2(){
        product.chooseTheProduct1();
    }
}
