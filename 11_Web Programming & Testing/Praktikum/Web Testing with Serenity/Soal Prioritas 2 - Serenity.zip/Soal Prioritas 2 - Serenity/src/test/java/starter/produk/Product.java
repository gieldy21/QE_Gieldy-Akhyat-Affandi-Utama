package starter.produk;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class Product extends PageObject{
    private By productsType(){
        return By.id("product_type_0");
    }
    private By numberPhoneField(){
        return By.id("phone_number");
    }
    private By ProductField(){
        return By.id("Axiata XL Rp5.000");
    }
    private By ProductField1(){
        return By.id("Axiata XL Rp10.000");
    }

    @Step
    public static OpenUrl url(String targetUrl){
        return new OpenUrl(targetUrl);
    }
    @Step
    public void validateOnTheHomePageSepulsa(){
        $(productsType()).isDisplayed();
    }
    @Step
    public void clickLogoPulsa(){
        $(productsType()).isClickable();
    }
    @Step
    public void enterNumberPhone(String phonenumber){
        $(numberPhoneField()).type(phonenumber);
    }
    @Step
    public void chooseTheProduct(){
        $(ProductField()).isClickable();
    }
    @Step
    public void chooseTheProduct1(){
        $(ProductField1()).isClickable();
    }
}
