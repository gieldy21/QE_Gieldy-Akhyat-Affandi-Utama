package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.Login;


public class LoginSteps {
    @Steps
    starter.user.Login login;

    @Given("I am on the login page")
    public void onTheLoginPage(){
        login.onTheLoginPage();
      }
    @When("I enter with valid username")
    public void enterValidUsername(){
        login.enterValidUsername();
    }
    @And("I enter with valid password")
    public void enterValidPassword(){
        login.enterValidPassword();
    }
    @Then("I login to Fakestore")
    public void loginFakestore(){
        login.loginFakestore();
    }
    @When("I enter with invalid username")
    public void enterInvalidUsername(){
        login.enterInvalidUsername();
    }
    @And("I enter with invalid password")
    public void enterInvalidPassword(){
        login.enterInvalidPassword();
    }
}

