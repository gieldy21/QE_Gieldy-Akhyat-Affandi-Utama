package starter.user;

import net.thucydides.core.annotations.Step;

public class Cart {
    @Step("I am on the product pages")
    public void onTheProductPages(){
        System.out.println("I am on the product pages");
    }
    @Step("I choose the product")
    public void chooseTheProduct(){
        System.out.println("I choose the product");
    }
    @Step("I click add to cart")
    public void clickAddToCart(){
        System.out.println("I click add to cart");
    }
    @Step("I see the product in to my cart")
    public void seeTheProductInMyCart(){
        System.out.println("I see the product in to my cart");
    }
    @Step("I click delete product in my cart")
    public void clickDeleteProductInMyCart(){
        System.out.println("I click delete product in my cart");
    }
    @Step("I see the product is not in my cart anymore")
    public void seeTheProductNotInMyCart(){
        System.out.println("I see the product is not in my cart anymore");
    }
}
