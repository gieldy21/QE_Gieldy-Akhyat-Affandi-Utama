package starter.user;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class Login {

    @Step("I am on the login page")
    public void onTheLoginPage(){
        System.out.println("I am on the login page");
    }
    @Step("I enter with valid username")
    public void enterValidUsername(){
        System.out.println("I enter with valid username");
    }
    @Step("I enter with valid password")
    public void enterValidPassword(){
        System.out.println("I enter with valid password");
    }
    @Step("I login to Fakestore")
    public void loginFakestore(){
        System.out.println("I login to Fakestore");
    }
    @Step("I enter with invalid username")
    public void enterInvalidUsername(){
        System.out.println("I enter with invalid username");
    }
    @Step("I enter with invalid password")
    public void enterInvalidPassword(){
        System.out.println("I enter with invalid password");
    }
}
