package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class CartSteps {
    @Steps
    starter.user.Cart cart;

    @Given("I am on the product pages")
    public void onTheProductPages(){
        cart.onTheProductPages();
    }
    @When("I choose the product")
    public void chooseTheProduct(){
        cart.chooseTheProduct();
    }
    @And("I click add to cart")
    public void clickAddToCart(){
        cart.clickAddToCart();
    }
    @Then("I see the product in to my cart")
    public void seeTheProductInMyCart(){
        cart.seeTheProductInMyCart();
    }
    @And("I click delete product in my cart")
    public void clickDeleteProductInMyCart(){
        cart.clickDeleteProductInMyCart();
    }
    @Then("I see the product is not in my cart anymore")
    public void seeTheProductNotInMyCart(){
        cart.seeTheProductNotInMyCart();
    }
}
