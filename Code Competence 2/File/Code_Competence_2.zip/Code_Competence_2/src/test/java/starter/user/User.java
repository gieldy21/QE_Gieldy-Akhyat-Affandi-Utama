package starter.user;

import net.thucydides.core.annotations.Step;

public class User {
    @Step("I am on user page")
    public void onUserPage(){
        System.out.println("I am on user page");
    }
    @Step("I click create account")
    public void clickCreateAccount(){
        System.out.println("I click create account");
    }
    @Step("I enter valid email")
    public void enterValidEmail(){
        System.out.println("I enter valid email");
    }
    @Step("I enter valid password")
    public void enterValidPassword(){
        System.out.println("I enter valid password");
    }
    @Step("I enter valid confirm password")
    public void enterValidConfirmPassword(){
        System.out.println("I enter valid confirm password");
    }
    @Step("I click submit")
    public void clickSubmit(){
        System.out.println("I click submit");
    }
    @Step("I success to create account")
    public void successToCreateAccount(){
        System.out.println("I success to create account");
    }
    @Step("I enter invalid confirm password")
    public void enterInvalidConfirmPassword(){
        System.out.println("I enter invalid confirm password");
    }
    @Step("I failed to create account")
    public void failedToCreateAccount(){
        System.out.println("I failed to create account");
    }
}
