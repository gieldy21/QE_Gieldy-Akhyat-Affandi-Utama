package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class UserSteps {
    @Steps
    starter.user.User user;

    @Given("I am on user page")
    public void onUserPage(){
        user.onUserPage();
    }
    @When("I click create account")
    public void clickCreateAccount(){
        user.clickCreateAccount();
    }
    @And("I enter valid email")
    public void enterValidEmail(){
        user.enterValidEmail();
    }
    @And("I enter valid password")
    public void enterValidPassword(){
        user.enterValidPassword();
    }
    @And("I enter valid confirm password")
    public void enterValidConfirmPassword(){
        user.enterValidConfirmPassword();
    }
    @And("I click submit")
    public void clickSubmit(){
        user.clickSubmit();
    }
    @Then("I success to create account")
    public void successToCreateAccount(){
        user.successToCreateAccount();
    }
    @And("I enter invalid confirm password")
    public void enterInvalidConfirmPassword(){
        user.enterInvalidConfirmPassword();
    }
    @Then("I failed to create account")
    public void failedToCreateAccount(){
        user.failedToCreateAccount();
    }
}
