package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ProdukSteps {
    @Steps
    starter.user.Produk produk;
    @Given("I am on the product page")
    public void onTheProductPage(){
        produk.onTheProductPage();
    }
    @When("I enter in field search product what i want")
    public void enterFieldSearchProduct(){
        produk.enterFieldSearchProduct();
    }
    @And("I click enter")
    public void clickEnter(){
        produk.clickEnter();
    }
    @Then("I see the product what i want")
    public void seeTheProduct(){
        produk.seeTheProduct();
    }
    @When("I enter in field search with invalid product")
    public void enterInvalidFieldSearchProduct(){
        produk.enterInvalidFieldSearchProduct();
    }
    @Then("I did'n see the product")
    public void didnSeeTheProduct(){
        produk.didnSeeTheProduct();
    }
}
