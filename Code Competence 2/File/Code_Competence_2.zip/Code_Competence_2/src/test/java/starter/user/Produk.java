package starter.user;

import net.thucydides.core.annotations.Step;

public class Produk {
    @Step("I am on the product page")
    public void onTheProductPage(){
        System.out.println("I am on the product page");
    }
    @Step("I enter in field search product what i want")
    public void enterFieldSearchProduct(){
        System.out.println("I enter in field search product what i want");
    }
    @Step("I click enter")
    public void clickEnter(){
        System.out.println("I click enter");
    }
    @Step("I see the product what i want")
    public void seeTheProduct(){
        System.out.println("I see the product what i want");
    }
    @Step("I enter in field search with invalid product")
    public void enterInvalidFieldSearchProduct(){
        System.out.println("I enter in field search with invalid product");
    }
    @Step("I did'n see the product")
    public void didnSeeTheProduct(){
        System.out.println("I did'n see the product");
    }
}
