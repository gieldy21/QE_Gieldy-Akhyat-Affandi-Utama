package test.alta.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import test.alta.pages.LoginScreen;
import test.alta.pages.RegisterScreen;

public class RegisterSteps {
    @Steps
    LoginScreen loginScreen;
    @Steps
    RegisterScreen registerScreen;

    @Given("new user on the login page")
    public void newUserOnTheLoginPage(){
        loginScreen.inLoginPage();
    }
    @When("user click create one for register")
    public void clickCreate(){
        registerScreen.clickCreate();
    }
    @And("user input name on Name field")
    public void inputName(){
        registerScreen.inputNameField();
    }
    @And("user input email on Email field")
    public void inputEmail(){
        registerScreen.inputEmailField();
    }
    @And("user input password on Password field")
    public void inputPassword(){
        registerScreen.inputPassword();
    }
    @And("user input password again on Confirm Password field")
    public void inputConfirmPassword(){
        registerScreen.confirmPassword();
    }
    @Then("user click Register button")
    public void clickRegister(){
        registerScreen.clickRegisterButton();
    }
}