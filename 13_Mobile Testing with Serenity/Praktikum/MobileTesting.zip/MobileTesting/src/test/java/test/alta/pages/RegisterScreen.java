package test.alta.pages;

import io.appium.java_client.MobileBy;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;
import test.alta.pageobject.BasePageObject;
import com.github.javafaker.Faker;

public class RegisterScreen extends BasePageObject {
    public String name = randomName();
    public String password = "test";

    private By CreateOne(){
        return MobileBy.id("textViewLinkRegister");
    }
    private By NameField(){
        return MobileBy.id("textInputEditTextName");
    }
    private By registerEmailField(){
        return MobileBy.id("textInputEditTextEmail");
    }
    private By registerPasswordField(){
        return MobileBy.id("textInputEditTextPassword");
    }
    private By confirmPasswordField(){
        return MobileBy.id("textInputEditTextConfirmPassword");
    }
    private By registerButton(){
        return MobileBy.id("appCompatButtonRegister");
    }

    @Step
    public void clickCreate(){
        onClick(CreateOne());
    }
    @Step
    public void inputNameField(){
        onType(NameField(), randomName());
    }

    public void inputEmailField(){
        onType(registerEmailField(), randomName() + "@gmail.com");
    }

    @Step
    public void inputPassword(){
        onType(registerPasswordField(), password);
    }

    @Step
    public void confirmPassword(){
        onType(confirmPasswordField(), password);
    }

    @Step
    public void clickRegisterButton(){
        onClick(registerButton());
    }

    public String randomName(){
        Faker faker = new Faker();
        return faker.name().firstName();
    }
}
